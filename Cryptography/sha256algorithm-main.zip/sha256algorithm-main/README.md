
![This is an image](./public/sha256.png)

# Sha256algorithm

Sha256 algorithm explained online step by step visually [sha256algorithm.com](https://sha256algorithm.com/)
This website will help you understand how a sha256 hash is calculated from start to finish.

I hope this will be helpful for students learning about hash functions and sha256.

The code it's quite messy and probably there are some parts that don't follow the react way.

Ask me anything at [@manceraio](https://twitter.com/manceraio)

## Install 

I built this using create-react-app. If you want to play with it, just install javascript dependencies:

`npm install`

and start local server:

`npm start`
